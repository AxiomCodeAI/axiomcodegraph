package com.example.greeter;

public class Greeting {
    private final String text;

    public Greeting(String text) {
        this.text = text;
    }

    public String shout() {
        return text.toUpperCase();
    }
}
