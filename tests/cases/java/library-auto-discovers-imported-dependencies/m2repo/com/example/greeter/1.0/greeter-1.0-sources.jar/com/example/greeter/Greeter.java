package com.example.greeter;

public class Greeter {
    public Greeting hello(String name) {
        return new Greeting("hello " + name);
    }
}
